import fs from 'node:fs';
import path from 'node:path';

import { load, dump } from 'js-yaml';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

type AnyRecord = Record<string, unknown>;

const DEFAULT_FALLBACK: AnyRecord = {
    url: 'https://www.gstatic.com/generate_204',
    interval: 300,
    lazy: true,
    timeout: 5000,
    'max-failed-times': 5,
    'expected-status': 204,
};

const DEFAULT_LOAD_BALANCE: AnyRecord = {
    url: 'https://www.gstatic.com/generate_204',
    interval: 300,
};

const FALLBACK_KEYS = new Set([
    'url',
    'interval',
    'lazy',
    'timeout',
    'max-failed-times',
    'expected-status',
]);

const LOAD_BALANCE_KEYS = new Set(['url', 'interval', 'lazy', 'strategy']);

@Injectable()
export class MihomoLayerService {
    private readonly logger = new Logger(MihomoLayerService.name);
    private readonly configPath: string;

    private cacheMtimeMs = 0;
    private cachedLayer: AnyRecord | null = null;
    private lastFailedMtimeMs = 0;
    private lastMissingLogMs = 0;

    constructor(private readonly configService: ConfigService) {
        const envPath =
            this.configService.get<string>('MIHOMO_LAYER_CONFIG_PATH') || 'configMi.yaml';
        this.configPath = path.isAbsolute(envPath)
            ? envPath
            : path.join(process.cwd(), envPath);
    }

    public applyIfMihomo(raw: unknown): string | null {
        if (typeof raw !== 'string') {
            return null;
        }

        if (!raw.includes('proxy-groups:') && !raw.includes('proxies:')) {
            return null;
        }

        let baseConfig: AnyRecord;
        try {
            const parsed = load(raw);
            if (!isRecord(parsed)) {
                return null;
            }
            baseConfig = parsed;
        } catch (error) {
            this.logger.debug(`Skipping YAML parse error: ${String(error)}`);
            return null;
        }

        if (!Array.isArray(baseConfig['proxy-groups']) && !Array.isArray(baseConfig['proxies'])) {
            return null;
        }

        const layerConfig = this.getLayerConfig();
        if (!layerConfig) {
            return null;
        }

        const updated = applyLayer(baseConfig, layerConfig);
        return dump(updated, {
            noRefs: true,
            lineWidth: -1,
            sortKeys: false,
        });
    }

    private getLayerConfig(): AnyRecord | null {
        let stats: fs.Stats;
        try {
            stats = fs.statSync(this.configPath);
        } catch (error) {
            const now = Date.now();
            if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
                if (now - this.lastMissingLogMs > 60_000) {
                    this.logger.warn(`configMi.yaml not found at ${this.configPath}`);
                    this.lastMissingLogMs = now;
                }
            } else {
                this.logger.warn(`Failed to stat configMi.yaml: ${String(error)}`);
            }
            return this.cachedLayer;
        }

        try {
            if (stats.mtimeMs === this.cacheMtimeMs && this.cachedLayer) {
                return this.cachedLayer;
            }
            if (stats.mtimeMs === this.lastFailedMtimeMs && this.cachedLayer) {
                return this.cachedLayer;
            }

            const raw = fs.readFileSync(this.configPath, 'utf-8');
            const parsed = load(raw);
            if (!isRecord(parsed)) {
                this.logger.warn('configMi.yaml is not a map, skipping layer.');
                return this.cachedLayer;
            }

            this.cacheMtimeMs = stats.mtimeMs;
            this.cachedLayer = parsed;
            this.lastFailedMtimeMs = 0;
            return this.cachedLayer;
        } catch (error) {
            if (stats.mtimeMs !== this.lastFailedMtimeMs) {
                this.logger.warn(`Failed to load configMi.yaml: ${String(error)}`);
                this.lastFailedMtimeMs = stats.mtimeMs;
            }
            return this.cachedLayer;
        }
    }
}

function applyLayer(baseConfig: AnyRecord, layerConfig: AnyRecord): AnyRecord {
    const deleteSet = extractDeleteSet(layerConfig);
    const replaceMap = extractReplaceMap(layerConfig);
    const hiddenList = extractHiddenList(layerConfig);
    const hiddenSet = new Set(hiddenList);

    const balanceGroups = buildBalanceGroups(layerConfig, replaceMap, deleteSet);
    const remakeGroups = buildRemakeGroups(layerConfig, replaceMap, deleteSet);
    const newGroups = [...balanceGroups, ...remakeGroups].filter((group) => {
        const name = typeof group.name === 'string' ? group.name : '';
        return name.length > 0 && !deleteSet.has(name);
    });

    const newGroupNames = newGroups
        .map((group) => (typeof group.name === 'string' ? group.name : ''))
        .filter((name) => name.length > 0);

    if (Array.isArray(baseConfig.proxies)) {
        baseConfig.proxies = baseConfig.proxies.filter((proxy) => {
            if (!isRecord(proxy) || typeof proxy.name !== 'string') {
                return true;
            }
            if (deleteSet.has(proxy.name)) {
                return false;
            }
            if (newGroupNames.includes(proxy.name)) {
                return false;
            }
            return true;
        });
    }

    let groups = Array.isArray(baseConfig['proxy-groups'])
        ? baseConfig['proxy-groups']
        : [];

    const cleanedGroups: AnyRecord[] = [];
    for (const group of groups) {
        if (!isRecord(group)) {
            continue;
        }
        const groupName = typeof group.name === 'string' ? group.name : '';
        if (groupName && deleteSet.has(groupName)) {
            continue;
        }
        const applyReplace = group.type === 'select';
        if (Array.isArray(group.proxies)) {
            group.proxies = rewriteProxiesList(
                group.proxies,
                replaceMap,
                deleteSet,
                applyReplace,
            );
        }
        cleanedGroups.push(group);
    }
    groups = cleanedGroups;

    groups = groups.filter(
        (group) => !(isRecord(group) && newGroupNames.includes(String(group.name))),
    );

    const selectIndex = groups.findIndex(
        (group) => isRecord(group) && group.type === 'select',
    );

    if (selectIndex < 0) {
        groups.push(...newGroups);
        baseConfig['proxy-groups'] = groups;
        return baseConfig;
    }

    groups.splice(selectIndex, 0, ...newGroups);
    const proxyGroup = groups[selectIndex + newGroups.length];
    updateProxyGroup(proxyGroup, baseConfig, {
        newGroupNames,
        hiddenSet,
        deleteSet,
        replaceMap,
    });

    baseConfig['proxy-groups'] = groups;
    return baseConfig;
}

function updateProxyGroup(
    proxyGroup: AnyRecord,
    baseConfig: AnyRecord,
    opts: {
        newGroupNames: string[];
        hiddenSet: Set<string>;
        deleteSet: Set<string>;
        replaceMap: Map<string, string>;
    },
): void {
    const { newGroupNames, hiddenSet, deleteSet, replaceMap } = opts;
    let proxies: string[] = [];

    if (Array.isArray(proxyGroup.proxies)) {
        proxies = rewriteProxiesList(proxyGroup.proxies, replaceMap, deleteSet, true);
    } else if (Array.isArray(baseConfig.proxies)) {
        proxies = baseConfig.proxies
            .filter((proxy) => isRecord(proxy) && typeof proxy.name === 'string')
            .map((proxy) => String(proxy.name));
        proxies = rewriteProxiesList(proxies, replaceMap, deleteSet, true);
    }

    proxies = proxies.filter((proxy) => !hiddenSet.has(proxy));

    const replaceTargets = new Set(replaceMap.values());
    const addable = newGroupNames.filter(
        (name) =>
            !replaceTargets.has(name) && !deleteSet.has(name) && !hiddenSet.has(name),
    );

    proxyGroup.proxies = dedupeKeepOrder([...addable, ...proxies]);
}

function buildRemakeGroups(
    layerConfig: AnyRecord,
    replaceMap: Map<string, string>,
    deleteSet: Set<string>,
): AnyRecord[] {
    const result: AnyRecord[] = [];
    const entries = normalizeList(layerConfig.remake);
    for (const entry of entries) {
        if (!isRecord(entry)) {
            continue;
        }
        const inputProxies = toStringList(
            entry['input-proxies'] ?? entry.input_proxies ?? [],
        );
        if (inputProxies.length === 0) {
            continue;
        }
        const explicitOutputName =
            entry['output-name'] ?? entry.output_name ?? entry.outputName ?? undefined;
        const baseName = String(explicitOutputName ?? entry.name ?? inputProxies[0]);
        const combineTags = Boolean(entry['combine-tags'] ?? entry.combine_tags ?? false);
        let groupName = combineTags ? deriveGroupName(baseName, inputProxies) : baseName;
        if (inputProxies.includes(groupName)) {
            const derived = deriveGroupName(baseName, inputProxies);
            groupName = derived;
            if (inputProxies.includes(groupName)) {
                groupName = `${baseName} AUTO`;
            }
        }
        const groupType = String(entry.type ?? 'fallback');
        const isHidden = Boolean(entry.hidden);
        const group: AnyRecord = {
            name: groupName,
            type: groupType,
            proxies: rewriteProxiesList(inputProxies, replaceMap, deleteSet, false),
        };
        if (isHidden) {
            group.hidden = true;
        }
        if (groupType === 'load-balance') {
            applyGroupFields(entry, group, DEFAULT_LOAD_BALANCE, LOAD_BALANCE_KEYS);
        } else {
            applyGroupFields(entry, group, DEFAULT_FALLBACK, FALLBACK_KEYS);
        }
        if (Array.isArray(group.proxies) && group.proxies.length > 0) {
            result.push(group);
        }
    }
    return result;
}

function buildBalanceGroups(
    layerConfig: AnyRecord,
    replaceMap: Map<string, string>,
    deleteSet: Set<string>,
): AnyRecord[] {
    const result: AnyRecord[] = [];
    const entries = normalizeList(layerConfig.balance);
    for (const entry of entries) {
        if (!isRecord(entry)) {
            continue;
        }
        const inputProxies = toStringList(
            entry['input-proxies'] ?? entry.input_proxies ?? [],
        );
        if (inputProxies.length === 0) {
            continue;
        }
        const groupName = String(entry.name ?? 'load-balance');
        const isHidden = Boolean(entry.hidden);
        const group: AnyRecord = {
            name: groupName,
            type: String(entry.type ?? 'load-balance'),
            proxies: rewriteProxiesList(inputProxies, replaceMap, deleteSet, false),
        };
        if (isHidden) {
            group.hidden = true;
        }
        applyGroupFields(entry, group, DEFAULT_LOAD_BALANCE, LOAD_BALANCE_KEYS);
        if (Array.isArray(group.proxies) && group.proxies.length > 0) {
            result.push(group);
        }
    }
    return result;
}

function extractHiddenList(layerConfig: AnyRecord): string[] {
    const hiddenCfg = layerConfig.hidden;
    if (isRecord(hiddenCfg)) {
        return toStringList(hiddenCfg['input-proxies'] ?? hiddenCfg.input_proxies ?? []);
    }
    return toStringList(hiddenCfg ?? []);
}

function extractDeleteSet(layerConfig: AnyRecord): Set<string> {
    const deleteCfg = layerConfig.delete;
    if (isRecord(deleteCfg)) {
        return new Set(toStringList(deleteCfg.proxies ?? []));
    }
    return new Set();
}

function extractReplaceMap(layerConfig: AnyRecord): Map<string, string> {
    const replaceCfg = layerConfig.replace;
    if (!isRecord(replaceCfg)) {
        return new Map();
    }
    const proxies = replaceCfg.proxies;
    if (!isRecord(proxies)) {
        return new Map();
    }
    const entries: [string, string][] = Object.entries(proxies).map(([key, value]) => [
        String(key),
        String(value),
    ]);
    return new Map(entries);
}

function rewriteProxiesList(
    proxies: unknown[],
    replaceMap: Map<string, string>,
    deleteSet: Set<string>,
    applyReplace: boolean,
): string[] {
    const result: string[] = [];
    for (const proxy of proxies) {
        if (typeof proxy !== 'string') {
            continue;
        }
        let value = proxy;
        if (applyReplace && replaceMap.has(proxy)) {
            value = replaceMap.get(proxy) || value;
        }
        if (deleteSet.has(value)) {
            continue;
        }
        result.push(value);
    }
    return dedupeKeepOrder(result);
}

function applyGroupFields(
    entry: AnyRecord,
    group: AnyRecord,
    defaults: AnyRecord,
    allowedKeys: Set<string>,
): void {
    for (const [key, value] of Object.entries(defaults)) {
        if (group[key] === undefined) {
            group[key] = value;
        }
    }
    for (const key of allowedKeys) {
        if (entry[key] !== undefined) {
            group[key] = entry[key];
        }
    }
}

function deriveGroupName(baseName: string, inputProxies: string[]): string {
    const match = baseName.match(/\[[^\]]+\]/);
    if (!match) {
        return baseName;
    }
    const tags: string[] = [];
    for (const proxy of inputProxies) {
        const tag = extractBracketTag(proxy);
        if (tag && !tags.includes(tag)) {
            tags.push(tag);
        }
    }
    if (tags.length === 0) {
        return baseName;
    }
    return baseName.replace(match[0], `[${tags.join('-')}]`);
}

function extractBracketTag(name: string): string | null {
    const match = name.match(/\[([^\]]+)\]/);
    return match ? match[1] : null;
}

function dedupeKeepOrder(items: string[]): string[] {
    const seen = new Set<string>();
    const result: string[] = [];
    for (const item of items) {
        if (seen.has(item)) {
            continue;
        }
        seen.add(item);
        result.push(item);
    }
    return result;
}

function normalizeList(value: unknown): unknown[] {
    return Array.isArray(value) ? value : [];
}

function toStringList(value: unknown): string[] {
    return normalizeList(value).filter((item) => typeof item === 'string') as string[];
}

function isRecord(value: unknown): value is AnyRecord {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
